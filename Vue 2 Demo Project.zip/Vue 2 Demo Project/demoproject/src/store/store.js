import axios from 'axios'
import Vue from 'vue'
import VueX from 'vuex'


Vue.use(VueX)

const store = new VueX.Store({
    state: {
        loggedIn: JSON.parse(localStorage.getItem("user")),
        users: [],
    },
    getters: {
        getUserData: state => {
            return state.users
        },
        getLoggedInUser: state => {
            return state.loggedIn
        }
    },
    mutations: {
        getUserData: (state, payload) => {
            let allUsers = []
            if (state.loggedIn.role == "admin") {
                allUsers = payload.filter(user =>
                    user.creator === state.loggedIn.email
                )
            } else {
                allUsers = payload.filter(user =>
                    user.role != "masterAdmin"
                )
            }

            state.users = allUsers
        },
        editUserData: (state, payload) => {
            state.users = state.users.map((user) => {
                if (user.email == payload.email) {
                    return payload
                } else {
                    return user
                }
            })
        },
        deleteUserData: (state, payload) => {
            state.users = state.users.filter(user => {
                return user.email != payload.email
            })
        },
        addUserData: (state, payload) => {
            state.users = [...state.users, payload]
        },
        logIn: (state, payload) => {
            state.loggedIn = payload
        },
        editDetails: (state, payload) => {
            localStorage.setItem("user", JSON.stringify(payload))
            state.loggedIn = payload
        }
    },
    actions: {
        getUserAction: ({ commit }) => {
            axios.get("/")
                .then(res => {
                    commit("getUserData", res.data)
                })
                .catch(err => {
                    console.log(err)
                })
        },
        editUserAction: ({ commit }, payload) => {
            axios.put("/editUser", payload)
                .then(res => {
                    commit("editUserData", res.data)
                })
                .catch(err => {
                    console.log(err)
                })
        },
        deleteUserAction: ({ commit }, payload) => {
            axios.post("/deleteUser", payload)
                .then(res => {
                    commit("deleteUserData", res.data)
                })
                .catch(err => {
                    console.log(err)
                })
        },
        addUserAction: ({ commit }, payload) => {
            commit("addUserData", payload)
        },
        loginAction: ({commit}, payload) => {
            commit("logIn", payload)
        },
        editDetailsAction: ({commit}, payload) => {
            commit("editDetails", payload)
        }
    }
})

export default store