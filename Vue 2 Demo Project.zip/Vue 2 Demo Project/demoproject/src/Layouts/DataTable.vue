<template>
  <div>
    <b-row v-if="!users.length">
      <b-col>
        <b-jumbotron bg-variant="info" text-variant="white" header-level="4" header="No Users Found">
          <p>New users that you add will be displayed here.</p>
        </b-jumbotron>
      </b-col>
    </b-row>
    <b-row v-else>
      <b-col>
        <b-table
          outlined
          bordered
          head-variant="light"
          table-variant="light"
          hover
          :items="users"
          :fields="fields"
          :per-page="perPage"
          :current-page="currentPage"
        >
          <template #cell(isApproved)="data">
            {{ data.item.isApproved ? "Approved" : "Not Approved" }}
          </template>
          <template #cell(edit)="data">
            <b-button @click="editUser(data)" variant="primary">Edit</b-button>
          </template>
          <template #cell(delete)="data">
            <b-button variant="danger" @click="deleteUser(data)"
              >Delete</b-button
            >
          </template>
        </b-table>
        <b-pagination
          v-model="currentPage"
          :total-rows="rows"
          :per-page="perPage"
        ></b-pagination>
        <b-modal centered v-model="show" title="Edit User">
          <b-container fluid>
            <b-form>
              <b-form-group id="email" label="Email">
                <b-form-input v-model="userData.email" disabled> </b-form-input>
              </b-form-group>
              <b-form-group label="Role">
                <b-form-select
                  v-model="userData.selectedRole"
                  :options="options"
                ></b-form-select>
              </b-form-group>
              <b-form-group label="Approval">
                <b-form-select
                  v-model="userData.isApproved"
                  :options="approvalOptions"
                ></b-form-select>
              </b-form-group>
            </b-form>
          </b-container>
          <template #modal-footer>
            <div class="w-100">
              <b-button
                variant="danger"
                size="sm"
                class="float-right"
                @click="show = false"
              >
                Close
              </b-button>
              <b-button
                variant="primary"
                size="sm"
                class="float-right mr-2"
                @click="onSubmit()"
              >
                Submit
              </b-button>
            </div>
          </template>
        </b-modal>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  props: ["users"],
  data() {
    return {
      tabIndex: 0,
      show: false,
      userData: {
        email: "",
        isApproved: "",
        selectedRole: "",
        creator: this.$store.state.loggedIn.email,
      },
      options: [
        { value: "user", text: "User" },
        { value: "admin", text: "Admin" },
      ],
      approvalOptions: [
        { value: true, text: "Approve User" },
        { value: false, text: "Discard User" },
      ],
      fields: [
        {
          key: "firstname",
          label: "First name",
        },
        {
          key: "lastname",
          label: "Last name",
        },
        {
          key: "email",
        },
        {
          key: "phone",
        },
        {
          key: "role",
        },
        {
          key: "isApproved",
          label: "Approved/Not Approved",
        },
        {
          key: "creator",
          label: "Created By",
        },
        {
          key: "updatedBy",
          label: "Updated By",
        },
        {
          key: "edit",
          label: "Edit",
        },
        {
          key: "delete",
          label: "Delete",
        },
      ],
      perPage: 5,
      currentPage: 1,
    };
  },
  mounted() {
    this.$store.dispatch("getUserAction");
  },
  beforeRouteLeave(to, from, next) {
    const user = this.getData();
    if (user) {
      next(false);
    } else {
      next();
    }
  },
  methods: {
    ...mapActions(["editUserAction", "deleteUserAction"]),
    editUser(data) {
      this.show = true;
      this.userData.email = data.item.email;
      this.userData.selectedRole = data.item.role;
      this.userData.isApproved = data.item.isApproved;
    },
    onSubmit() {
      this.editUserAction(this.userData);
      this.show = false;
    },
    deleteUser(data) {
        this.$bvModal.msgBoxConfirm('Are you sure?')
          .then((value) => {
            if(value)
              this.deleteUserAction(data.item);
          })
          .catch(err => {
            console.log(err)
          })
    },
  },
  computed: {
    rows() {
      return this.users.length;
    },
  },
};
</script>

<style scoped>
</style>