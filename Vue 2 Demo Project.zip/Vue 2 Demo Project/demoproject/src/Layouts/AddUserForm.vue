<template>
  <b-container fluid class="mt-2">
    <b-row>
      <b-col cols="5">
        <b-card
          title="Add User"
          bg-variant="light"
          text-variant="dark"
          border-variant="info"
          ><div v-if="isErr">
            <b-alert show variant="danger">{{ errMsg }}</b-alert>
          </div>
          <hr />
          <b-card-text>
            <b-form @submit.prevent="onSubmit">
              <b-form-group
                id="firstname"
                label="First name"
                label-for="firstname"
              >
                <b-form-input
                  v-model="userData.firstname"
                  id="firstname"
                  type="text"
                  required
                  placeholder="Enter first name"
                ></b-form-input>
              </b-form-group>
              <b-form-group
                id="lastname"
                label="Last name"
                label-for="lastname"
              >
                <b-form-input
                  v-model="userData.lastname"
                  id="lastname"
                  type="text"
                  required
                  placeholder="Enter last name"
                ></b-form-input>
              </b-form-group>
              <b-form-group id="email" label="User Email" label-for="email">
                <b-form-input
                  v-model="userData.email"
                  id="email"
                  type="email"
                  required
                  placeholder="Enter email"
                ></b-form-input>
              </b-form-group>
              <b-form-group id="phone" label="Phone" label-for="phone">
                <b-form-input
                  v-model="userData.phone"
                  id="phone"
                  type="tel"
                  required
                  placeholder="Enter phone number"
                ></b-form-input>
              </b-form-group>
              <b-form-group id="password" label="Password" label-for="password">
                <b-form-input
                  v-model="userData.password"
                  id="password"
                  type="password"
                  required
                  placeholder="Enter password"
                ></b-form-input>
              </b-form-group>
              <b-button type="submit" variant="primary" block
                >Add User</b-button
              >
            </b-form>
          </b-card-text>
        </b-card>
      </b-col>
      <b-col class="image-container" cols="7"> </b-col>
    </b-row>
  </b-container>
</template>


<script>
import { mapActions } from "vuex";
import axios from "axios";
export default {
  data() {
    return {
      userData: {
        creator: this.getData().email,
        firstname: "",
        lastname: "",
        email: "",
        phone: "",
        password: "",
      },
      errMsg: "",
      isErr: false,
    };
  },
  methods: {
    ...mapActions(["addUserAction"]),
    onSubmit() {
      axios
        .post("/addUser", this.userData)
        .then((res) => {
          this.makeToast("success", "User added successfully");
          this.addUserAction(res.data.newUser);
          this.userData = {
            creator: this.getData().email,
            firstname: "",
            lastname: "",
            email: "",
            phone: "",
            password: "",
          };
          this.$emit("switch-tab");
        })
        .catch((err) => {
          this.errMsg = err.response.data.message;
          this.isErr = true;
          setTimeout(() => {
            this.errMsg = "";
            this.isErr = false;
          }, 5000);
        });
    },
  },
};
</script>

<style scoped>
.image-container {
  background-image: url("../../public/undraw_Add_notes_re_ln36.png");
  background-size: contain;
  background-repeat: no-repeat;
  height: 80vh;
}
</style>