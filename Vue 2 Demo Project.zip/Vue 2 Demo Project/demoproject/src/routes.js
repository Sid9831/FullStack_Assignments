import HomePage from './components/HomePage.vue'
import SignIn from './components/SignIn.vue'
import SignUp from './components/SignUp.vue'
import MasterDashboard from './components/MasterRoutes/MasterDashboard.vue'
import AdminDashboard from './components/AdminRoutes/AdminDashboard.vue'
import UserDashboard from './components/UserRoutes/UserDashboard.vue'
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
export const routes = [
    {
        path: "", component: HomePage, name: "home", meta: {requiresAuth: false}
    },
    {
        path: "/signin", component: SignIn, name: "signin", meta: {requiresAuth: false}
    },
    {
        path: "/signup", component: SignUp, name: "signup", meta: {requiresAuth: false}
    },
    {
        path: "/master", component: MasterDashboard, name: "master", meta: {requiresAuth: true, masterAuth: true}
    },
    {
        path: "/admin", component: AdminDashboard, name: "admin", meta: {requiresAuth: true, adminAuth: true}
    },
    {
        path: "/user", component: UserDashboard, name: "user", meta: {requiresAuth: true, userAuth: true}
    },
    {
        path: "*", redirect: { name: "signin" }
    }
]

const router = new VueRouter({
    routes,
    mode: "history"
})

router.beforeEach((to, from, next) => {
    const auth = JSON.parse(localStorage.getItem("user"))

    if(to.meta.requiresAuth){
        if(!auth){
            next({name: "signin"})
        }
        else if(to.meta.masterAuth) {
            if(auth.role == "masterAdmin")
                next()
            else
                next({name: "signin"})
        }
        else if(to.meta.adminAuth){
            if(auth.role == "admin")
                next()
            else
                next({name: "signin"})
        }
        else if(to.meta.userAuth){
            if(auth.role == "user")
                next()
            else
                next({name: "signin"})
        }
    }
    else if(!to.meta.requiresAuth) {
        if(auth && auth.role == "masterAdmin")
            next({name: "master"})
        else if(auth && auth.role == "admin")
            next({name: "admin"})
        else if(auth && auth.role == "user")
            next({name: "user"})
        else 
            next()
    }else 
        next()
})

export default router