<template>
  <div>
    <b-navbar toggleable="sm" type="dark" variant="info">
      <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

      <b-collapse id="nav-collapse" is-nav>
        <b-navbar-nav>
          <b-nav-item
            ><router-link tag="li" :to="{ name: 'home' }"
              >Home</router-link
            ></b-nav-item
          >
        </b-navbar-nav>

        <b-navbar-nav class="ml-auto" v-if="isLoggedin">
          <b-nav-item
            ><li variant="light" @click="logOut">Log out</li></b-nav-item
          >
        </b-navbar-nav>

        <b-navbar-nav class="ml-auto" v-else>
          <b-navbar-nav>
            <b-nav-item
              ><router-link tag="li" :to="{ name: 'signin' }"
                >Sign In</router-link
              ></b-nav-item
            >
            <b-nav-item
              ><router-link tag="li" :to="{ name: 'signup' }"
                >Sign Up</router-link
              ></b-nav-item
            >
          </b-navbar-nav>
        </b-navbar-nav>
      </b-collapse>
    </b-navbar>
  </div>
</template>

<script>
import { eventBus } from "../main.js";
export default {
  data() {
    return {
      user: null,
      isLoggedin: false,
    };
  },
  mounted() {
    eventBus.$on("logged-in", () => {
      this.user = this.getData();
      this.isLoggedin = true;
    });
    const user = this.getData();
    if (user) {
      this.isLoggedin = true;
    }
  },

  methods: {
    logOut() {
      this.$bvModal
        .msgBoxConfirm("Are you sure?")
        .then((value) => {
          if (value) {
            this.isLoggedin = false;
            localStorage.clear();
            this.$router.push({ name: "signin" });
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
  },
};
</script>

<style scoped>
</style>