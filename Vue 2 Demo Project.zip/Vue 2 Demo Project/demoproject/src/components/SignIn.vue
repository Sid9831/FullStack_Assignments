<template>
    <b-container fluid class="mt-2">
      <b-row>
        <b-col class="image-container" cols="7">
        </b-col>
        <b-col class="mt-4" cols="4">
          <b-card style="box-shadow: 0px 7px 10px grey" border-variant="info" title="Sign In" class="mb-2">
            <b-form-text v-if="isInvalid"
              ><span class="text-danger" style="font-size: 15px"
                >One of the input fields is invalid. Please try again</span
              ></b-form-text
            >
            <hr />
            <b-card-text>
              <b-form @submit.prevent="OnSubmit" class="mt-4">
                <b-row>
                  <b-col cols="12">
                    <b-form-group id="email" label="Email:" label-for="email">
                      <b-form-input
                        :class="{ error: $v.userData.email.$error }"
                        v-model="userData.email"
                        @blur="$v.userData.email.$touch()"
                        id="email"
                        type="email"
                        placeholder="Enter email"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.email.$error &&
                          $v.userData.email.$dirty &&
                          userData.email == ''
                        "
                        ><span class="text-danger"
                          >Email is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          !$v.userData.email.email &&
                          $v.userData.email.$dirty &&
                          $v.userData.email.$error
                        "
                        ><span class="text-danger"
                          >Please enter a valid email.</span
                        ></b-form-text
                      >
                    </b-form-group>
                  </b-col>

                  <b-col cols="12">
                    <b-form-group
                      id="password"
                      label="Password:"
                      label-for="password"
                    >
                      <b-form-input
                        @blur="$v.userData.password.$touch()"
                        :class="{ error: $v.userData.password.$error }"
                        v-model="userData.password"
                        id="password"
                        type="password"
                        placeholder="Enter password"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.password.$error &&
                          $v.userData.password.$dirty &&
                          userData.password == ''
                        "
                        ><span class="text-danger"
                          >Password is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          (!$v.userData.password.minLength ||
                            !$v.userData.password.maxLength) &&
                          $v.userData.password.$dirty
                        "
                        ><span class="text-danger"
                          >Password must be between 6 and 12 characters in
                          length</span
                        ></b-form-text
                      >
                    </b-form-group>
                    <hr />
                  </b-col>
                  <b-col>
                    <b-button block type="submit" variant="primary"
                      >Sign In</b-button
                    >
                    <div v-if="isErr">
                      <br />
                      <b-alert show variant="danger">{{ errMsg }}</b-alert>
                    </div>
                  </b-col>
                </b-row>
              </b-form>
            </b-card-text>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
</template>


<script>
import {mapActions} from 'vuex'
import {eventBus} from '../main.js'
import axios from "axios";
import {
  required,
  email,
  minLength,
  maxLength,
} from "vuelidate/lib/validators";
export default {
  data() {
    return {
      userData: {
        email: "",
        password: "",
      },
      isInvalid: false,
      isErr: false,
      errMsg: "",
    };
  },
  methods: {
    ...mapActions(["loginAction"]),
    OnSubmit() {
      if (this.$v.userData.$invalid) {
        this.isInvalid = true;
        setTimeout(() => {
          this.isInvalid = false;
        }, 5000);
        return;
      }

      axios
        .post("/signIn", this.userData)
        .then((res) => {
          const {user} = res.data
          this.loginAction(user)
          if(user.role == "masterAdmin"){
            this.storeData(user)
            this.$router.push({name: "master"})
          }else if(user.role == "admin"){
            this.storeData(user)
            this.$router.push({name: "admin"})
          }else {
            if(user.role == "user" && !user.isApproved){
              this.makeToast("danger", "Your account has not been approved. Please try again later.")
              return
            }else {
              this.storeData(user)
              this.$router.push({name: "user"})
            }
          }
          eventBus.$emit("logged-in", user)
        })
        .catch((err) => {
          this.errMsg = err.response.data.message;
          this.isErr = true;
          setTimeout(() => {
            this.errMsg = "";
            this.isErr = false;
          }, 5000);
        });
    },
  },
  validations: {
    userData: {
      email: {
        required,
        email,
      },
      password: {
        required,
        minLength: minLength(6),
        maxLength: maxLength(12),
      },
    },
  },
};
</script>


<style scoped>
.error {
  border-color: red;
  box-shadow: 1px 1px 1px red;
}

.image-container{
  background-image: url("../../public/undraw_Login_re_4vu2.png");
  background-size: contain;
  background-repeat: no-repeat;
  height: 85vh;
}
</style>