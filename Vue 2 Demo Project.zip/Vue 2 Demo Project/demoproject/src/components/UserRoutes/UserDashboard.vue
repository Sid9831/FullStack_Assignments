<template>
  <b-container fluid class="mt-4">
    <b-row v-if="!edit">
      <b-col cols="6" offset="3">
        <b-card header="User Details">
          <b-list-group>
            <b-list-group-item>
              <div>
                <h5 class="mb-2">First Name:</h5>
              </div>
              <p class="mb-1">
                {{ getLoggedInUser.firstname }}
              </p></b-list-group-item
            >
            <b-list-group-item>
              <div>
                <h5 class="mb-2">Last Name:</h5>
              </div>
              <p class="mb-1">
                {{ getLoggedInUser.lastname }}
              </p></b-list-group-item
            >
            <b-list-group-item>
              <div>
                <h5 class="mb-2">Email:</h5>
              </div>
              <p class="mb-1">
                {{ getLoggedInUser.email }}
              </p></b-list-group-item
            >
            <b-list-group-item>
              <div>
                <h5 class="mb-2">Phone:</h5>
              </div>
              <p class="mb-1">
                {{ getLoggedInUser.phone }}
              </p></b-list-group-item
            >
            <b-list-group-item>
              <div>
                <h5 class="mb-2">Role:</h5>
              </div>
              <p class="mb-1">
                {{ getLoggedInUser.role }}
              </p></b-list-group-item
            >
          </b-list-group>
          <b-button class="mt-2" variant="primary" @click="edit = true" block
            >Edit Details</b-button
          >
        </b-card>
      </b-col>
    </b-row>
    <b-row v-if="edit">
      <edit-user @go-back="edit = false" :user="getLoggedInUser"></edit-user>
    </b-row>
  </b-container>
</template>

<script>
import { mapGetters } from "vuex";
import EditUser from "./EditUser.vue";
export default {
  components: {
    EditUser,
  },
  data() {
    return {
      edit: false,
    };
  },
  computed: {
    ...mapGetters(["getLoggedInUser"]),
  },
};
</script>

<style scoped>
</style>