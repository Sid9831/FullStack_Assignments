<template>
  <b-col cols="6" offset="3">
    <b-card
      title="Edit Details"
      bg-variant="light"
      text-variant="dark"
      border-variant="primary"
      ><div v-if="isErr">
        <br />
        <b-alert show variant="danger">{{ errMsg }}</b-alert>
      </div>
      <hr />
      <b-card-text>
        <b-form @submit.prevent="onSubmit">
          <b-form-group id="firstname" label="First name" label-for="firstname">
            <b-form-input
              v-model="userData.firstname"
              id="firstname"
              type="text"
              required
              placeholder="Enter first name"
            ></b-form-input>
          </b-form-group>
          <b-form-group id="lastname" label="Last name" label-for="lastname">
            <b-form-input
              v-model="userData.lastname"
              id="lastname"
              type="text"
              required
              placeholder="Enter last name"
            ></b-form-input>
          </b-form-group>
          <b-form-group id="phone" label="Phone" label-for="phone">
            <b-form-input
              v-model="userData.phone"
              id="phone"
              type="tel"
              required
              placeholder="Enter phone number"
            ></b-form-input>
          </b-form-group>
          <b-button type="submit" variant="primary" block>Save Changes</b-button>
          <b-button block variant="secondary" @click="$emit('go-back')"
            >Back</b-button
          >
        </b-form>
      </b-card-text>
    </b-card>
  </b-col>
</template>

<script>
import axios from "axios"
import {mapActions} from "vuex"
export default {
  props: ["user"],
  emits: ["go-back"],
  data() {
    return {
      userData: {
        firstname: this.user.firstname,
        lastname: this.user.lastname,
        email: this.user.email,
        phone: this.user.phone,
      },
      errMsg: "",
      isErr: false,
    };
  },
  methods: {
    ...mapActions(["editDetailsAction"]),
    onSubmit() {
        axios.post("/editUserDetails", this.userData)
        .then(res => {
            this.makeToast("success", "Details edited successfully!")
            this.editDetailsAction(res.data)
        })
        .catch(err => {
            console.log(err)
        })
        this.$emit("go-back")
    }
  }
};
</script>