<template>
  <div>
    <div>
      <b-jumbotron>
        <template #header>Welcome</template>

        <template #lead> First demo project, using VueJS. </template>

        <hr class="my-4" />

        <p>
          It allows a user to Sign-up and Sign-in. The master admin can change the
          roles of these users.
        </p>

        <router-link tag="button" class="btn btn-primary mr-2" :to="{ name: 'signup' }"
          >SIGN UP</router-link
        >
        <router-link tag="button" class="btn btn-success" :to="{ name: 'signin' }"
          >SIGN IN</router-link
        >
      </b-jumbotron>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
</style>