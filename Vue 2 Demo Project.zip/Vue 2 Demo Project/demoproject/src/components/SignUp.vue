<template>
    <b-container fluid class="mt-4">
      <b-row v-if="!submitted">
        <b-col class="image-container" cols="5">
            <img src="undraw_Sign_in_re_o58h (1).png" alt="">
        </b-col>
        <b-col offset="1" cols="5">
          <b-card style="box-shadow: 0px 7px 10px grey" border-variant="info" title="Sign Up">
            <b-form-text v-if="isInvalid"
              ><span class="text-danger"
                >One or more of the input fields is invalid. Please try again</span
              ></b-form-text
            >
            <hr />
            <b-card-text>
              <b-form @submit.prevent="OnSubmit" class="mt-4">
                <b-row>
                  <b-col cols="6">
                    <b-form-group
                      id="firstname"
                      label="First name:"
                      label-for="firstname"
                    >
                      <b-form-input
                        @blur="$v.userData.firstname.$touch()"
                        :class="{ error: $v.userData.firstname.$error }"
                        v-model="userData.firstname"
                        id="firstname"
                        type="text"
                        placeholder="Enter first name"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.firstname.$error &&
                          $v.userData.firstname.$dirty &&
                          userData.firstname == ''
                        "
                        ><span class="text-danger"
                          >First name is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          $v.userData.firstname.$error &&
                          $v.userData.firstname.$dirty &&
                          !$v.userData.firstname.alpha
                        "
                        ><span class="text-danger"
                          >Only characters are allowed</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          $v.userData.firstname.$error &&
                          $v.userData.firstname.$dirty &&
                          !$v.userData.firstname.minLength
                        "
                        ><span class="text-danger"
                          >First name must be atleast 3 characters long</span
                        ></b-form-text
                      >
                    </b-form-group>
                  </b-col>
                  <b-col cols="6">
                    <b-form-group
                      id="lastname"
                      label="Last name:"
                      label-for="lastname"
                    >
                      <b-form-input
                        @blur="$v.userData.lastname.$touch()"
                        :class="{ error: $v.userData.lastname.$error }"
                        v-model="userData.lastname"
                        id="lastname"
                        type="text"
                        placeholder="Enter last name"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.lastname.$error &&
                          $v.userData.lastname.$dirty &&
                          userData.lastname == ''
                        "
                        ><span class="text-danger"
                          >Last name is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          $v.userData.lastname.$error &&
                          $v.userData.lastname.$dirty &&
                          !$v.userData.lastname.alpha
                        "
                        ><span class="text-danger"
                          >Only characters are allowed</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          $v.userData.lastname.$error &&
                          $v.userData.lastname.$dirty &&
                          !$v.userData.lastname.minLength
                        "
                        ><span class="text-danger"
                          >Last name must be atleast 3 characters long</span
                        ></b-form-text
                      >
                    </b-form-group>
                  </b-col>
                  <b-col cols="12">
                    <b-form-group id="email" label="Email:" label-for="email">
                      <b-form-input
                        @blur="$v.userData.email.$touch()"
                        :class="{ error: $v.userData.email.$error }"
                        v-model="userData.email"
                        id="email"
                        type="email"
                        placeholder="Enter email"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.email.$error &&
                          $v.userData.email.$dirty &&
                          userData.email == ''
                        "
                        ><span class="text-danger"
                          >Email is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          !$v.userData.email.email &&
                          $v.userData.email.$dirty &&
                          $v.userData.email.$error
                        "
                        ><span class="text-danger"
                          >Please enter a valid email.</span
                        ></b-form-text
                      >
                    </b-form-group>
                  </b-col>
                  <b-col cols="12">
                    <b-form-group id="phone" label="Phone:" label-for="phone">
                      <b-form-input
                        @blur="$v.userData.phone.$touch()"
                        :class="{ error: $v.userData.phone.$error }"
                        v-model.number="userData.phone"
                        id="phone"
                        type="tel"
                        placeholder="Enter phone number"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.phone.$error &&
                          $v.userData.phone.$dirty &&
                          userData.phone == null
                        "
                        ><span class="text-danger"
                          >Phone is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          !$v.userData.phone.numeric ||
                          ((!$v.userData.phone.minLength ||
                            !$v.userData.phone.maxLength) &&
                            $v.userData.phone.$dirty &&
                            $v.userData.phone.$error)
                        "
                        ><span class="text-danger"
                          >Enter a valid phone number</span
                        ></b-form-text
                      >
                    </b-form-group>
                  </b-col>
                  <b-col cols="12">
                    <b-form-group
                      id="password"
                      label="Password:"
                      label-for="password"
                    >
                      <b-form-input
                        @blur="$v.userData.password.$touch()"
                        :class="{ error: $v.userData.password.$error }"
                        v-model="userData.password"
                        id="password"
                        type="password"
                        placeholder="Enter password"
                        required
                      ></b-form-input>
                      <b-form-text
                        v-if="
                          $v.userData.password.$error &&
                          $v.userData.password.$dirty &&
                          userData.password == ''
                        "
                        ><span class="text-danger"
                          >Password is required</span
                        ></b-form-text
                      >
                      <b-form-text
                        v-else-if="
                          (!$v.userData.password.minLength ||
                            !$v.userData.password.maxLength) &&
                          $v.userData.password.$dirty
                        "
                        ><span class="text-danger"
                          >Password must be between 6 and 12 characters in
                          length</span
                        ></b-form-text
                      >
                    </b-form-group>
                    <hr />
                  </b-col>
                  <b-col>
                    <b-button block type="submit" variant="primary"
                      >Create Account</b-button
                    >
                    <div v-if="isErr">
                      <br />
                      <b-alert show variant="danger">{{ errMsg }}</b-alert>
                    </div>
                  </b-col>
                </b-row>
              </b-form>
            </b-card-text>
          </b-card>
        </b-col>
      </b-row>
      <b-row v-else>
        <b-col offset="3" cols="6">
          <div>
            <b-card title="Details submitted">
              <b-card-text>
                Your details have been submitted to the admin for approval.
              </b-card-text>

              <router-link
                tag="button"
                class="btn btn-primary"
                :to="{ name: 'home' }"
                >Back To Home</router-link
              >
            </b-card>
          </div>
        </b-col>
      </b-row>
    </b-container>
</template>


<script>
import axios from "axios";
import {
  required,
  email,
  minLength,
  maxLength,
  numeric,
  alpha,
} from "vuelidate/lib/validators";
export default {
  data() {
    return {
      userData: {
        firstname: "",
        lastname: "",
        email: "",
        phone: null,
        password: "",
      },
      submitted: false,
      isInvalid: false,
      isErr: false,
      errMsg: "",
    };
  },
  methods: {
    OnSubmit() {
      if (this.$v.userData.$invalid) {
        this.isInvalid = true;
        setTimeout(() => {
          this.isInvalid = false;
        }, 5000);
        return;
      }

      axios
        .post("/addUser", this.userData)
        .then((res) => {
          console.log(res);
          this.submitted = true;
        })
        .catch((err) => {
          this.errMsg = err.response.data.message;
          this.isErr = true;
          setTimeout(() => {
            this.errMsg = "";
            this.isErr = false;
          }, 5000);
        });
    },
  },
  validations: {
    userData: {
      firstname: {
        required,
        minLength: minLength(3),
        alpha,
      },
      lastname: {
        required,
        minLength: minLength(3),
        alpha,
      },
      email: {
        required,
        email,
      },
      phone: {
        required,
        minLength: minLength(10),
        maxLength: maxLength(10),
        numeric,
      },
      password: {
        required,
        minLength: minLength(6),
        maxLength: maxLength(12),
      },
    },
  },
};
</script>


<style scoped>
.error {
  border-color: red;
  box-shadow: 1px 1px 1px red;
}


</style>