<template>
  <b-container fluid>
    <b-tabs v-model="tabIndex" class="mt-4">
      <b-tab title="All Users" active class="mt-4">
        <data-table :users="getUserData"></data-table>
      </b-tab>
      <b-tab title="Add User">
        <keep-alive>
          <add-user-form @switch-tab="tabIndex = 0"></add-user-form>
        </keep-alive>
      </b-tab>
    </b-tabs>
  </b-container>
</template>

<script>
import { mapGetters } from "vuex";
import DataTable from "../../Layouts/DataTable.vue";
import AddUserForm from "../../Layouts/AddUserForm.vue";
export default {
  components: {
    DataTable,
    AddUserForm,
  },
  computed: {
    ...mapGetters(["getUserData"]),
  },
  mounted() {
    this.$store.dispatch("getUserAction");
  },
  data() {
    return {
      tabIndex: 0
    }
  }
};
</script>

<style scoped>
</style>