import Vue from 'vue'
import App from './App.vue'
import {BootstrapVue, ModalPlugin, ToastPlugin} from 'bootstrap-vue'
import store from './store/store'
import router from './routes'
import Vuelidate from 'vuelidate'
import axios from 'axios'

axios.defaults.baseURL = "http://localhost:5000/users"

Vue.config.productionTip = false
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.use(ModalPlugin)
Vue.use(BootstrapVue)
Vue.use(ToastPlugin)
Vue.use(Vuelidate)

export const eventBus = new Vue()

Vue.mixin({
  computed: {
    userDetails() {
      return JSON.parse(localStorage.getItem("user"))
    },
  },
  methods: {
    storeData(user) {
      localStorage.setItem("user",JSON.stringify(user))
    },
    getData() {
      const user = JSON.parse(localStorage.getItem("user"))
      if(user) {
        return user
      }else {
        return null
      }
    },
    makeToast(variant = null, body) {
      this.$bvToast.toast(body, {
        title: "Toast message",
        variant: variant,
        solid: true,
        autoHideDelay: 5000
      })
    }
  }
})



new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
