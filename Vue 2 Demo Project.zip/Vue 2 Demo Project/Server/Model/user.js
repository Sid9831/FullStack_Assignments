import mongoose from 'mongoose'

const userSchema  = mongoose.Schema({
    firstname: {
        type: String,
        required: true
    },
    lastname: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    isApproved: {
        type: Boolean,
        default: false
    },
    role: {
        type: String,
        default: "user"
    },
    creator: {
        type: String,
        default: null
    },
    updatedBy: {
        type: String,
        default: null
    }
})

const User = mongoose.model("users", userSchema)

export default User