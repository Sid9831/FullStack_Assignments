import User from '../Model/user.js'
import bcrypt from 'bcrypt'


export const addUser = async (req, res) => {

    const { firstname, lastname, email, phone, password, creator } = req.body

    try {
        const user = await User.findOne({ email })

        if (user) {
            return res.status(400).json({ message: "User already exist. Please try with a different email address" })
        }

        const encryptPassword = await bcrypt.hash(password, 12)

        const newUser = await User.create({ firstname, lastname, email, phone, password: encryptPassword, creator })

        return res.status(201).json({ newUser })
    }
    catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}

export const signIn = async (req, res) => {
    const { email, password } = req.body

    try {
        const user = await User.findOne({ email })

        if (!user) {
            return res.status(404).json({ message: "The email you entered is not connected to any account. Please try again." })
        }

        const isPasswordcorrect = await bcrypt.compare(password, user.password)

        if (!isPasswordcorrect) {
            return res.status(400).json({ message: "The password you entered is wrong. Please try again." })
        }

        return res.status(200).json({ user })
    }
    catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}

export const getUsers = async (req, res) => {

    try {
        const users = await User.find()

        if (users) {
            return res.status(200).json(users)
        }

        return res.status(404).json({ message: "No users exist" })

    }
    catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}

export const editUser = async (req, res) => {
    console.log("inside edit")
    const { email, isApproved, selectedRole, creator } = req.body

    try {

        const result = await User.findOneAndUpdate({ email: email }, { isApproved: isApproved, role: selectedRole, updatedBy: creator }, { new: true })
        return res.status(200).json(result)


    } catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}

export const deleteUser = async (req, res) => {
    const { email } = req.body
    try {
        const result = await User.findOneAndDelete({ email: email })
        console.log(result)
        return res.status(200).json(result)
    } catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}

export const editUserDetails = async (req, res) => {
    console.log("inside edit details")
    const { firstname, lastname, email, phone } = req.body
    try {

        const result = await User.findOneAndUpdate({ email: email }, { firstname: firstname, lastname: lastname, phone: phone }, { new: true })
        return res.status(200).json(result)
    } catch (error) {
        return res.status(500).json({ message: "Something went wrong. Please try again later." })
    }
}