import express from 'express'
import { addUser, signIn, getUsers, editUser, deleteUser, editUserDetails} from '../Controller/userController.js'

const router = express.Router()

router.get('/', getUsers)
router.post('/addUser', addUser)
router.post('/signIn', signIn)
router.put('/editUser', editUser)
router.post("/deleteUser", deleteUser)
router.post("/editUserDetails", editUserDetails)

export default router

