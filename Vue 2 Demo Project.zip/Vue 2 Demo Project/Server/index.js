import bodyParser from "body-parser";
import cors from 'cors'
import mongoose from 'mongoose'
import express from 'express'
import userRoute from './Routes/userRoutes.js'

const app = express()

app.use(bodyParser.json({ extended: true }))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(cors())

app.use("/users", userRoute)

const URL = 'mongodb+srv://siddharth:siddharth3198@cluster0.u7sux.mongodb.net/VueProject?retryWrites=true&w=majority'
const PORT = '5000'

mongoose.connect(URL, { useNewUrlParser: true, useUnifiedTopology: true }).then(() => {
    app.listen(PORT, () => console.log(`Server is running on PORT: ${PORT}`))
}).catch((error) => {
    console.log('Error:', error.message)
})


