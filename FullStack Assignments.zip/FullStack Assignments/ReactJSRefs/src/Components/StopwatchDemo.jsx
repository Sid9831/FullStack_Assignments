import React, {useState, useRef} from 'react'

function StopWatch(){

    const [count, setCount] = useState(0)
    const userRef = useRef(0)

    const startTimer = () => {
        if(userRef.current){
            return
        }
        userRef.current = setInterval(() => setCount(count => count + 1), 1000)
    }

    const stopTimer = () => {
        clearInterval(userRef.current)
        userRef.current = 0
    }

    return(
        <>
        Timer: {count}
        <button onClick={startTimer}>Start</button>
        <button onClick={stopTimer}>Stop</button>
        </>
    )
}

export default StopWatch