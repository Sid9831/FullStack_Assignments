import React, {useState} from 'react'

function RefAndState(){

    const [count, setCount] = useState(0)

    const handlerFunction = () => {
        const updatedcount = count + 1
        console.log(`Clicked ${updatedcount} times`)
        setCount(updatedcount)
    }

    return <button onClick={handlerFunction}>Click me!!!</button>

}

export default RefAndState