import React from "react";

class RefCallback extends React.Component{
    constructor(){
        super()
        this.state = {count: 0}
    }

    updateState(){
        this.setState({count: this.inputType.value})
    }

    render(){
        return(
            <>
            Counts<input type="text" ref = {(call_back) => this.inputType=call_back} onChange={this.updateState.bind(this)}/>
            <p>{this.state.count}</p>
            </>
        )
    }

}

export default RefCallback