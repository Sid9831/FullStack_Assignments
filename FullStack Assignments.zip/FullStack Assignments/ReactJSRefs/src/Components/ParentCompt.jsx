import React, { useEffect, useRef } from "react";
import InputComp from "./ForwardRef";

function ParentComp(){

    const fnameref = useRef(null)
    const lnameref = useRef(null)
    const submitref = useRef(null)

    useEffect(()=>{
        fnameref.current.focus()
    }, [])

    function fnameBox(e){
        if(e.key === "Enter"){
            lnameref.current.focus()
        }
    }

    function lnameBox(e){
        if(e.key === "Enter"){
            submitref.current.focus()
        }
    }

    function submitBox(e){
        if(e.key === "Enter"){
            alert("Form submitted")
        }
    }

    return(
        <>
        <InputComp type="text" onKeyDown={(e)=>fnameBox(e)} placeholder="enter you fname"  ref={fnameref}/><br/>
        <InputComp type="text" onKeyDown={(e)=>lnameBox(e)} placeholder="enter your lname"  ref={lnameref}/><br/>
        <button type="submit" onKeyDown={(e)=>submitBox(e)}  ref={submitref}>Submit</button>
        </>
    )
}

export default ParentComp