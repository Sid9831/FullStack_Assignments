import { forwardRef } from "react";

const InputComp = forwardRef((props, ref) => {
    return (
        <input type={props.type} onKeyDown={props.onKeyDown} placeholder={props.placeholder} ref={ref} />
    )
})

//Instead of above, you can also do this:

/*

function Input (props, ref){
    return(
        <input type={props.type} onKeyDown={props.onKeyDown} placeholder={props.placeholder} ref={ref} />
    )
}

function ForwardInput = forwardRef(Input)

export default ForwardInput

*/ 


export default InputComp


