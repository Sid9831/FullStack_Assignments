import React from "react";

class RefClass extends React.Component{
    constructor(){
        super()
        this.state = {count: 0}
    }


    updateState(e){
        this.setState({count: this.refs.inputRef.value})
    }


    render(){
        return(
            <>
            Count<input type="text" ref="inputRef" onChange={this.updateState.bind(this)}/>
            <p>{this.state.count}</p>
            </>
        )
    }

}

export default RefClass