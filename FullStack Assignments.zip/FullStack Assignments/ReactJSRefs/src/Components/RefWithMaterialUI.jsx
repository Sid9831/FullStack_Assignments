import React, { useRef } from "react";
import {TextField} from '@material-ui/core'

function RefWithMUI(){
    const inputRefVal = useRef()
    const showRefVal = () => {
        alert(inputRefVal.current.value)
    }

    return(
        <>
        <TextField inputRef={inputRefVal}/>
        <button onClick={showRefVal}>Click me</button>
        </>
    )
}

export default RefWithMUI