import React, {useRef, useState, createRef} from 'react'


const RefsDemo = () => {
    const [count, updateCount] = useState(0)

    const useRefDemo = useRef() 
    const createRefDemo = createRef()   //Will set the initial value to null, no matter what.

    if(!useRefDemo.current){
        useRefDemo.current = count
    }


    if(!createRefDemo.current){
        createRefDemo.current = count
    }

    const changeCount = () => {
        updateCount(count => count + 1)
    }

    return(
        <>
        <p>Count: {count}</p>
        <p>useRefDemo: {useRefDemo.current}</p>
        <p>createRefDemo: {createRefDemo.current}</p>
        <button onClick={changeCount}>Click me!!!</button>
        </>
    )


}

export default RefsDemo


