import './App.css';
// import RefClass from './Components/RefsWithoutHooks';
// import RefCallback from './Components/RefsUsingCallback';
import RefsDemo from './Components/UseRefAndCreateRef';
// import RefAndState from './Components/RefAndState';
// import StopWatch from './Components/StopwatchDemo';
// import RefWithMUI from './Components/RefWithMaterialUI';
// import ParentComp from './Components/ParentCompt';


function App() {
  return (
    // <ParentComp/>
    <RefsDemo/>
    // <RefClass/>
    // <RefCallback/>
    // <RefAndState/>
    // <StopWatch/>
    // <RefWithMUI/>
  );
}

export default App;
