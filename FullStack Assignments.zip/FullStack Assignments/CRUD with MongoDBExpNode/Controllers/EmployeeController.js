const express = require('express')
// const { route } = require('express/lib/application')
var router = express.Router()
const mongoose = require('mongoose')
const Employee = mongoose.model('Employee')     //returns a mongoose object for the collection 'Employee'


router.get('/', (req, res)=>{
    res.render("employee/addOrEdit", {
        viewTitle: "Insert Employee"    //replaces '{{viewTitle}}' with 'Insert Employee'
    })
})

router.post('/', (req, res)=>{
    if(req.body._id == ''){
        insertDocument(req, res)
    }
    else{
        updateDocument(req, res)
    }
})

function insertDocument(req, res){
    var employee = new Employee()
    employee.fullName = req.body.fullName
    employee.email = req.body.email
    employee.mobile = req.body.mobile
    employee.city = req.body.city
    employee.Age = req.body.Age
    employee.Salary = req.body.Salary
    employee.save((err, doc) => {
        if(!err)
        res.redirect('/employee/list')   //This paths are not case sensitive
        else{
            if(err.name = "ValidationError"){
                handleValidationError(err, req.body)
                res.render("employee/addOrEdit", {
                    viewTitle : "Insert Employee",
                    employee: req.body           //prints the error messages and keeps the user data in the respective fields
                })
            }
            else{
                console.log("Error during record insertion: " + err)
            }
        }
    })
}

router.get('/list', (req, res)=>{
    Employee.find((err, docs)=>{
        if(!err){
            res.render("employee/list", {
                list: JSON.parse(JSON.stringify(docs))      //Stringify takes a JSON object and converts it into JSON
                                                            //string. parse() takes the json string and converts into an object.
                                                            //A json object and a normal object is different.
                                                            //Data is processed in JSON format but to display it, it is needed to
                                                            //convert it into a normal object.
            })
        }
        else{
            console.log("Error in retrieving employee list: " + err) 
        }
    }) 
})

function handleValidationError(err, body){
    for(field in err.errors){
        switch(err.errors[field].path){
            case "fullName":
                body["fullNameError"] = err.errors[field].message
                break;
            case "email":
                body["emailError"] = err.errors[field].message
                break;
            case "mobile":
                body["mobileError"] = err.errors[field].message
                break;
            case "city":
                body["cityError"] = err.errors[field].message
                break;
            case "Age":
                body["AgeError"] = err.errors[field].message
                break;
            case "Salary":
                body["SalaryError"] = err.errors[field].message
                break
            default:
                break;
        }
    }
}

//'Inserting' logic ends here.
router.get('/:id', (req, res)=>{
    Employee.findById(req.params.id, (err, doc)=>{
        
        if(!err){
            res.render('employee/addOrEdit', {
                viewTitle: "Update Employee",
                employee: JSON.parse(JSON.stringify(doc))
            })
        }
    })
})

function updateDocument(req, res){
    //FindOneAndReplace must be used or else the validations will not be checked properly
    Employee.findOneAndReplace({_id: req.body._id}, req.body, {new:true}, (err, doc)=>{
        if(!err) res.redirect('employee/list')
        else{
            if(err.name = "ValidationError"){
                handleValidationError(err, req.body)
                res.render('employee/addOrEdit', {
                    viewTitle: "Update Employee",
                    employee : req.body
                })
            }
            else{
                console.log("Error updating record" + err)
            }
        }
    })
}

router.get('/delete/:id', (req, res)=>{
    Employee.findByIdAndRemove(req.params.id, (err, doc)=>{
        if(!err){
            Employee.find((err, docs)=>{
                res.render('employee/list', {
                    list: JSON.parse(JSON.stringify(docs))
                })
            })
        }
        else{
            console.log("Error in deleting record!!!" + err)
        }
    })
})




module.exports = router;    //The module.exports is used to export any literal, function or object as a module.