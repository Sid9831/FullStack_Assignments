//Middlewares are codes that run in the server on the incoming request object, before sending a response. 
//So they basically 'transforms' a request

require('./Models/db')

const express = require('express')
const path = require('path')
const ehbs = require('express-handlebars')
const bodyparser = require('body-parser')

var app = express()
app.use(bodyparser.urlencoded({
    extended: true
}))
app.use(bodyparser.json())//bodyparser.json() will return a function, and when that function is used in app.use, 
//it acts as any other middleware. Node.js request body parsing middleware which parses the incoming request body before your handlers,
// and make it available under req.body property. In other words, it simplifies the incoming request.
app.set('views', path.join(__dirname, '/Views/'))   //'views' is one of the properties of set() method which is to define
//the path from where views should be rendered.
app.engine('hbs', ehbs({extname: 'hbs', defaultLayout: 'mainLayout', layoutsDir: __dirname + '/Views/Layout'}))
app.set('view engine', 'hbs') // 'view engine' is one of the properties of set() used to specify the default
//template engine extension to use. Here we use 'hbs' (handlebars). 

app.listen(3000, () => {
    console.log("Express server started at port no: 3000")
})

var employeeController = require('./Controllers/EmployeeController')
app.use('/employee', employeeController)






