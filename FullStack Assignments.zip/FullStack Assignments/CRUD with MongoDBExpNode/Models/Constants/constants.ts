export class Constants{
    static FullNameRegEx = /^([a-zA-Z ]{2,40})$/;
    static EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
    static ConNoRegEx = /^([0-9]{10})$/;
    static AgeRegEx = /^([0-9]{1,2})$/;
}