const Consts = require('./Constants/constants')

const mongoose = require('mongoose')

var employeeSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: 'Full name is required'
    },
    email: {
        type: String,
        required: 'Email is required'
    },
    mobile: {
        type: String,
        required: 'Mobile no. is required'
    },
    city: {
        type: String,
        required: 'City is required'
    },
    Age: {
        type: Number,
        required: 'Age is required'
    },
    Salary: {
        type: Number,
        required: 'Salary is required'
    }
})

//FullName validation
employeeSchema.path('fullName').validate((val)=>{
    return Consts.Constants.FullNameRegEx.test(val)
},'Invalid Full Name!!!')

//Email Validation
employeeSchema.path('email').validate((val)=>{
    return Consts.Constants.EmailIdRegEx.test(val)
},'Please enter a valid email id.')

//Mobile Validation
employeeSchema.path('mobile').validate((val)=>{
    return Consts.Constants.ConNoRegEx.test(val)
},'Please enter a valid mobile number.')

//Age validation
employeeSchema.path('Age').validate((val)=>{
    return Consts.Constants.AgeRegEx.test(val)
},'Please enter a valid age.')



mongoose.model("Employee", employeeSchema)  


