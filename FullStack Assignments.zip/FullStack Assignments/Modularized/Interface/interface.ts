export interface IValidator{
    isValid(s: string|number, regex):boolean;
}