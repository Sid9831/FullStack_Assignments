import { Constants } from "./constants/constants"
import { ValidatorClass } from "./Validator/validator"


var Fname = "Siddharth"
var Lname = "Patel"
var email = "siddharth3198@gmail.com"
var zipcode = "3875"
var Age = 23
var contact = "91755"

var Obj = new ValidatorClass

console.log("Is email id valid or not: " + Obj.isValid(email, Constants.emailRegex))
console.log("Is zipcode valid or not: " + Obj.isValid(zipcode, Constants.ZipCodeRegex))
console.log("Is Fname valid or not: " + Obj.isValid(Fname, Constants.FNameLNameRegEx))
console.log("Is Lname valid or not: " + Obj.isValid(Lname, Constants.FNameLNameRegEx))
console.log("Is the age valid or not :" + Obj.isValid(Age, Constants.AgeRegEx))
console.log("Is contact No valid or not: " + Obj.isValid(contact, Constants.ConNoRegEx))
