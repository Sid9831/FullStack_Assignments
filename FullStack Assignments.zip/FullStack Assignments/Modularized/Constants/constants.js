"use strict";
exports.__esModule = true;
exports.Constants = void 0;
var Constants = /** @class */ (function () {
    function Constants() {
    }
    Constants.emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constants.ZipCodeRegex = /^[0-9]{6,12}$/;
    Constants.FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
    Constants.PasswordRegEx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;
    Constants.AgeRegEx = /^([0-9]{2,3})$/;
    Constants.ConNoRegEx = /^([0-9]{10})$/;
    return Constants;
}());
exports.Constants = Constants;
