export class Constants {
    static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    static ZipCodeRegex = /^[0-9]{6,12}$/; 
    static FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
    static PasswordRegEx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;
    static AgeRegEx = /^([0-9]{2,3})$/;
    static ConNoRegEx = /^([0-9]{10})$/;
}