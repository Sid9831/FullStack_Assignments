import { Constants } from "../constants/constants"; 
import { IValidator } from "../interface/interface";

export class ValidatorClass implements IValidator{
    isValid(s: string|number, regex): boolean {
        return regex.test(s)
    }
}

