"use strict";
exports.__esModule = true;
exports.ValidatorClass = void 0;
var ValidatorClass = /** @class */ (function () {
    function ValidatorClass() {
    }
    ValidatorClass.prototype.isValid = function (s, regex) {
        return regex.test(s);
    };
    return ValidatorClass;
}());
exports.ValidatorClass = ValidatorClass;
