import express from 'express';
import { signUp, showdata, signIn } from '../Controller/userController.js';

const router = express.Router()

router.get('/show', showdata)
router.post('/api/auth/signin', signIn)
router.post('/api/auth/signup', signUp)

export default router