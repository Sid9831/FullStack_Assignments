import mongoose from 'mongoose'

const userSchema = mongoose.Schema({
    firstname: String,
    lastname: String,
    username: String,
    email: String,
    password: String
});


var Users = mongoose.model("Users", userSchema)

export default Users