import Users from "../Model/userSchema.js";
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const secret = "GodIsGreat"

export const signUp = async(req, res) => {
    const {firstname, lastname, username, email, password} = req.body

    try{
        
        const olduser = await Users.findOne({username})

        if(olduser){
            return res.status(400).json({message:"User already exist!!"})
        }

        const encryptPassword = await bcrypt.hash(password, 12)

        const result = await Users.create({firstname, lastname, username, email, password: encryptPassword})

        res.status(201).json({result, message: "User Created"})
    }
    catch(error)
    {
        res.status(500).json({message: "Something went wrong!!"})
    }
}

export const signIn = async (req, res) => {
    const {username, password} = req.body

    try{
        const olduser = await Users.findOne({username})

        if(!olduser){
            return res.status(404).json({message: "User not found"})
        }

        const isPasswordCorrect = await bcrypt.compare(password, olduser.password)

        if(!isPasswordCorrect){
            return res.status(400).json({message: "Invalid Password"})
        }

        const token = jwt.sign({username: olduser.username, id: olduser._id}, secret, {expiresIn: "7d"})

        res.status(200).json({accessToken: token, olduser})
    }
    catch(error)
    {
        res.status(500).json({message:"Something went wrong"})
    }
}

export const showdata = async(req, res) => {
    try{
        const users = await Users.find()
        res.status(200).json(users)
    }
    catch(error){
        res.status(400).json(error.message)
    }
}