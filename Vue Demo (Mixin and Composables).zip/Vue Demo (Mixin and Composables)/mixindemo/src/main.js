import Vue from 'vue'
import App from './App.vue'
import store from './store/store'
import {mapActions, mapGetters} from 'vuex'
Vue.config.productionTip = false

Vue.mixin({
  computed: {
    ...mapGetters(["getUser"]),
  },
  methods: {
    ...mapActions(["setUserAction"]),
    setData(data) {
      console.log("Inside mixin setData() method: ", data)
      this.setUserAction(data)
    }
  }
})

new Vue({
  render: h => h(App),
  store
}).$mount('#app')
