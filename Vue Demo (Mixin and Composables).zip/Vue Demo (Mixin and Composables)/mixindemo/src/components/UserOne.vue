<template>
    <div>
        <ul>
            <li v-for="(value, key) in userOne" :key="key">{{key}} - {{value}}</li>
        </ul>
        <button @click="setData(userOne)">Set data</button>
    </div>
</template>

<script>
export default {
    data() {
        return {
            userOne: {
                name: "Hitesh",
                age: 23,
                email: "hs@gmail.com",
                phone: 7984335398
            }
        }
    }
}
</script>

<style scoped>

</style>