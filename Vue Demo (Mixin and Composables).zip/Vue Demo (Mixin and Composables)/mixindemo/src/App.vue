<template>
  <div>
    <h3>Current User: {{ getUser ? getUser.name : "" }}</h3>
    <hr>
    <user-one></user-one>
    <hr />
    <user-two></user-two>
  </div>
</template>

<script>
import UserOne from "./components/UserOne.vue";
import UserTwo from "./components/UserTwo.vue";
export default {
  components: {
    UserOne,
    UserTwo,
  },
};
</script>

<style scoped>
</style>