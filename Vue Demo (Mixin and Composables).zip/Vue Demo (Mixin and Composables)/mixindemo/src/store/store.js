import Vue from 'vue'
import VueX from 'vuex'

Vue.use(VueX)

const store = new VueX.Store({
    state: {
        user: null
    },
    getters: {
        getUser: state => {
            return state.user
        }   
    },
    mutations: {
        setUser: (state, payload) => {
            state.user = payload
            localStorage.setItem("user", JSON.stringify(payload))
        }
    },
    actions: {
        setUserAction: ({commit}, payload) => {
            commit("setUser", payload)
        }
    }
})

export default store