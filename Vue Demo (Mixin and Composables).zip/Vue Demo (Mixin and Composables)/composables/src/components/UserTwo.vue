<template>
    <div>
        <ul>
            <li v-for="(value, key) in userTwo" :key="key">{{key}} - {{value}}</li>
        </ul>
        <button @click="setData(userTwo)">Set data</button>
    </div>
</template>

<script>
import useComposableDemo from '../main'
export default {
    data() {
        return {
            userTwo: {
                name: "Mehul",
                age: 23,
                email: "mp@gmail.com",
                phone: 9173460055
            }
        }
    },
    setup() {
        const {setData} = useComposableDemo()
        return {setData}
    }
}
</script>

<style scoped>

</style>