import { createApp, computed } from 'vue'
import App from './App.vue'
import store from './store/store'
import { useStore } from 'vuex'

export default function useComposableDemo() {

    const store = useStore()
    const getUser = computed(function () {
        return store.getters.getUser
    })


    function setData(data) {
        console.log(data)
        store.dispatch("setUserAction", data)
    }

    return { setData, getUser }
}



const app = createApp(App)
app.use(store)
app.mount('#app')