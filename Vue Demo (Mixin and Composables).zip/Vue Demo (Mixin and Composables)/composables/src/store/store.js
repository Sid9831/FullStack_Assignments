import { createStore } from "vuex";

const store = createStore({
    state: {
        user: null
    },
    getters: {
        getUser: state => {
            return state.user
        }   
    },
    mutations: {
        setUser: (state, payload) => {
            state.user = payload
            localStorage.setItem("user", JSON.stringify(payload))
        }
    },
    actions: {
        setUserAction: ({commit}, payload) => {
            commit("setUser", payload)
        }
    }
})

export default store